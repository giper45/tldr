# gtalk

> This command is an alias of GNU `talk`.

- View documentation for the original command:

`tldr -p linux talk`
