# gdirname

> This command is an alias of GNU `dirname`.

- View documentation for the original command:

`tldr -p linux dirname`
