# glibtoolize

> This command is an alias of GNU `libtoolize`.

- View documentation for the original command:

`tldr -p linux libtoolize`
