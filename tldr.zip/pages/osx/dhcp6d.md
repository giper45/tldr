# dhcp6d

> Stateless DHCPv6 server. See also: `InternetSharing`.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/dhcp6d/>.

- Start the daemon:

`dhcp6d`

- Use a custom configuration:

`dhcp6d {{path/to/config_file}}`
