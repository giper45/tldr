# gnproc

> This command is an alias of GNU `nproc`.

- View documentation for the original command:

`tldr -p linux nproc`
