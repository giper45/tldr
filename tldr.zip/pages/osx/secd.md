# secd

> Controls access to and modification of keychain items.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/secd.8.html>.

- Start the daemon:

`secd`
