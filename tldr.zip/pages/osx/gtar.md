# gtar

> This command is an alias of GNU `tar`.

- View documentation for the original command:

`tldr -p linux tar`
