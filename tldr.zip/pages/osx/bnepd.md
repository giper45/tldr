# bnepd

> A service that handles all Bluetooth network connections.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/bnepd.8.html>.

- Start the daemon:

`bnepd`
