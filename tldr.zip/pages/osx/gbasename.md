# gbasename

> This command is an alias of GNU `basename`.

- View documentation for the original command:

`tldr -p linux basename`
