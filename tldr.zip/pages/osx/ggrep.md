# ggrep

> This command is an alias of GNU `grep`.

- View documentation for the original command:

`tldr -p linux grep`
