# gusers

> This command is an alias of GNU `users`.

- View documentation for the original command:

`tldr -p linux users`
