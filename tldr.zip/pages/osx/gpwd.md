# gpwd

> This command is an alias of GNU `pwd`.

- View documentation for the original command:

`tldr -p linux pwd`
