# guptime

> This command is an alias of GNU `uptime`.

- View documentation for the original command:

`tldr -p linux uptime`
