# ghostname

> This command is an alias of GNU `hostname`.

- View documentation for the original command:

`tldr -p linux hostname`
