# gecho

> This command is an alias of GNU `echo`.

- View documentation for the original command:

`tldr -p linux echo`
