# reboot

> Reboot the system.
> More information: <https://keith.github.io/xcode-man-pages/reboot.8.html>.

- Reboot immediately:

`sudo reboot`

- Reboot immediately without gracefully shutting down:

`sudo reboot -q`
