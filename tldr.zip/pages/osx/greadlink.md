# greadlink

> This command is an alias of GNU `readlink`.

- View documentation for the original command:

`tldr -p linux readlink`
