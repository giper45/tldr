# coreaudiod

> Service for Core Audio, Apple's audio system.
> It should not be invoked manually.
> More information: <https://developer.apple.com/library/archive/documentation/MusicAudio/Conceptual/CoreAudioOverview/WhatisCoreAudio/WhatisCoreAudio.html>.

- Start the daemon:

`coreaudiod`
