# securityd

> This manages security contexts and cryptographic operations.
> Works with secd for keychain access.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/securityd.1.html>.

- Start the daemon:

`securityd`
