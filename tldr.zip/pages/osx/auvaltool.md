# auvaltool

> AudioUnit validation tool for Mac.
> More information: <https://keith.github.io/xcode-man-pages/auvaltool.1.html>.

- List all [a]vailable AudioUnits of any type:

`auvaltool -a`

- List all [a]vailable AudioUnits of any type with their [l]ocation:

`auvaltool -al`
