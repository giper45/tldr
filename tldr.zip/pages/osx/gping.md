# gping

> This command is an alias of GNU `ping`.

- View documentation for the original command:

`tldr -p linux ping`
