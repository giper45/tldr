# gping6

> This command is an alias of GNU `ping6`.

- View documentation for the original command:

`tldr -p linux ping6`
