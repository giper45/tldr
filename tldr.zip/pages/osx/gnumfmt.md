# gnumfmt

> This command is an alias of GNU `numfmt`.

- View documentation for the original command:

`tldr -p linux numfmt`
