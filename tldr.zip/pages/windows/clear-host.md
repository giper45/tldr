# Clear-Host

> Clears the screen.
> This command can only be used through PowerShell.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/clear-host>.

- Clear the screen:

`cls`
